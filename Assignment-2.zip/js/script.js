$(document).ready(function () {
    $("button").mouseenter(function () {   
            $(".container").show();
    });
    $("button").mouseout(function () {
        $(".container").hide();
    });
});