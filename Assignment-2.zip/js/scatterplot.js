
        // set the dimensions and margins of the graph
        var margin = { top: 10, right: 30, bottom: 30, left: 60 },
            width = 480 - margin.left - margin.right,
            height = 400 - margin.top - margin.bottom;

        var xValue = function (d) { return d['Horsepower(HP)']; }; // data -> value
        var yValue = function (d) { return d['Engine Size (l)']; }; // data -> value
        // setup fill color
        var cValue = function (d) { return d.Cyl; },
            color = d3.scaleOrdinal(d3.schemeCategory10);
        // append the svg object to the body of the page
        var svg = d3.select("#my_dataviz")
            .append("svg")
            .attr("width", width + margin.left + margin.right)
            .attr("height", height + margin.top + margin.bottom)
            .append("g")
            .attr("transform",
                "translate(" + margin.left + "," + margin.top + ")");

        //Read the data
        d3.csv("https://imld.de/docs/lehre/ws_18-19/data-vis/data/cars.csv").then(function (carData) {

            // Add X axis
            var x = d3.scaleLinear()
                .domain([0, 520])
                .range([0, width]);
            svg.append("g")
                .attr("transform", "translate(0," + height + ")")
                .call(d3.axisBottom(x))
                .append("text")
                .attr("fill", "#000")
                .attr("transform", "rotate(0)")
                .attr("y", -7)
                .attr("dx", "39.4em")
                .attr("text-anchor", "end")
                .text("Horsepower(HP)");

            // Add Y axis
            var y = d3.scaleLinear()
                .domain([0, 7])
                .range([height, 0]);
            svg.append("g")
                .call(d3.axisLeft(y))
                .append("text")
                .attr("fill", "#000")
                .attr("transform", "rotate(-90)")
                .attr("y", 6)
                .attr("dy", "0.9em")
                .attr("text-anchor", "end")
                .text("Engine Size (l)");

            // Add dots
            svg.append('g')
                .selectAll("dot")
                .data(carData)
                .enter()
                .append("circle")
                .attr("class", "dot")
                .attr("r",1.5)//radius of scatter plot.
                .attr("cx", function (d) { return x(d['Horsepower(HP)']); })
                .attr("cy", function (d) { return y(d['Engine Size (l)']); })
                .style("fill", function (d) { return color(cValue(d)); })
                .on("mouseover", function (d) {
                    Draw(d['Name']);
                    document.getElementById('sixAtt').style.display = "block";
                })
            /*.on("mouseout", function (d) {
                document.getElementById('sixAtt').style.display = "none";
            });*/

            // draw legend
            var legend = svg.selectAll(".legend")
                .data(color.domain())
                .enter().append("g")
                .attr("class", "legend")
                .attr("transform", function (d, i) { return "translate(0," + i * 20 + ")"; });

            // draw legend colored rectangles
            legend.append("rect")
                .attr("x", width - 4)
                .attr("width", 18)
                .attr("height", 18)
                .style("fill", color);

            // draw legend text
            legend.append("text")
                .attr("x", width + 30)
                .attr("y", 9)
                .attr("dy", ".35em")
                .style("text-anchor", "end")
                .text(function (d) { return d; })

            /* ===== Cylinder of the car ===== */

        })


function Draw(carName) {
    var b, c, d, e, f;
    var width = 300, height = 300;
    // ����һ�������������Ҫ����ͼ��Ԫ��
    var main = d3.select('.container svg').append('g')
        .classed('main', true)
        .attr('transform', "translate(" + width / 2 + ',' + height / 2 + ')');
    // ģ������


    // �趨һЩ�������ĳ���
    var radius = 100,
        // ָ��ĸ�������fieldNames�ĳ���
        total = 6,
        // ��Ҫ������ֳɼ������������ϴ�С�����ж��ٸ��������
        level = 4,
        // ����ķ�Χ������������
        rangeMin = 0,
        rangeMax = 100,
        arc = 2 * Math.PI;
    // ÿ��ָ�����ڵĽǶ�
    var onePiece = arc / total;
    // ���������������ε�����
    var polygons = {
        webs: [],
        webPoints: []
    };
    for (var k = level; k > 0; k--) {
        var webs = '',
            webPoints = [];
        var r = radius / level * k;
        for (var i = 0; i < total; i++) {
            var x = r * Math.sin(i * onePiece),
                y = r * Math.cos(i * onePiece);
            webs += x + ',' + y + ' ';
            webPoints.push({
                x: x,
                y: y
            });
        }
        polygons.webs.push(webs);
        polygons.webPoints.push(webPoints);
    }
    // ��������
    var webs = main.append('g')
        .classed('webs', true);
    webs.selectAll('polygon')
        .data(polygons.webs)
        .enter()
        .append('polygon')
        .attr('points', function (d) {
            return d;
        });
    // ��������
    var lines = main.append('g')
        .classed('lines', true);
    lines.selectAll('line')
        .data(polygons.webPoints[0])
        .enter()
        .append('line')
        .attr('x1', 0)
        .attr('y1', 0)
        .attr('x2', function (d) {
            return d.x;
        })
        .attr('y2', function (d) {
            return d.y;
        });














    d3.csv("https://imld.de/docs/lehre/ws_18-19/data-vis/data/cars.csv").then(function getValue(carData) {
        var num = 0;
        //�������
        for (var i = 1; i <= carData.length; i++) {
            if (carData[i]['Name'] == carName) {
                num = i; break;
            }

        }
        document.getElementById('table').rows[0].childNodes[3].innerText = carData[num]['Name'];
        document.getElementById('table').rows[1].childNodes[3].innerText = carData[num]['Type'];
        document.getElementById('table').rows[2].childNodes[3].innerText = carData[num]['AWD'];
        document.getElementById('table').rows[3].childNodes[3].innerText = carData[num]['RWD'];
        document.getElementById('table').rows[4].childNodes[3].innerText = carData[num]['Retail Price'];
        document.getElementById('table').rows[5].childNodes[3].innerText = carData[num]['Dealer Cost'];
        document.getElementById('table').rows[6].childNodes[3].innerText = carData[num]['Engine Size (l)'];


        var data = {
            fieldNames: ['HorsePower', 'CMPG', 'Engine Size', 'Cylinder', 'Retail Price', 'HMPG'],
            values: [
                [carData[num]['Horsepower(HP)'] / 493 * 100,
                    carData[num]['Engine Size (l)'] / 6 * 100,
                    carData[num]['City Miles Per Gallon'] / 60 * 100,
                    carData[num]['Cyl'] / 12 * 100,
                    carData[num]['Retail Price'] / 192465 * 100,
                    carData[num]['Highway Miles Per Gallon'] / 66 * 100]]

            //�˴��޸���ز���������ͨ��csv¼��

        }
        // �����״�ͼ��������
        var areasData = [];
        var values = data.values;
        for (var i = 0; i < values.length; i++) {
            var value = values[i],
                area = '',
                points = [];
            for (var k = 0; k < total; k++) {
                var r = radius * (value[k] - rangeMin) / (rangeMax - rangeMin);
                var x = r * Math.sin(k * onePiece),
                    y = r * Math.cos(k * onePiece);
                area += x + ',' + y + ' ';
                points.push({
                    x: x,
                    y: y
                })
            }
            areasData.push({
                polygon: area,
                points: points
            });
        }
        // ����g������������״�ͼ����
        var areas = main.append('g')
            .classed('areas', true);
        // ����g������������һ���״�ͼ�����µĶ�����Լ�Բ��
        areas.selectAll('g')
            .data(areasData)
            .enter()
            .append('g')
            .attr('class', function (d, i) {
                return 'area' + (i + 1);
            });
        for (var i = 0; i < areasData.length; i++) {
            // ����ѭ��ÿ���״�ͼ����
            var area = areas.select('.area' + (i + 1)),
                areaData = areasData[i];
            // �����״�ͼ�����µĶ����
            area.append('polygon')
                .attr('points', areaData.polygon)
                .attr('stroke', function (d, index) {
                    return getColor(i);
                })
                .attr('fill', function (d, index) {
                    return getColor(i);
                });
            // �����״�ͼ�����µĵ�
            var circles = area.append('g')
                .classed('circles', true);
            circles.selectAll('circle')
                .data(areaData.points)
                .enter()
                .append('circle')
                .attr('cx', function (d) {
                    return d.x;
                })
                .attr('cy', function (d) {
                    return d.y;
                })
                .attr('r', 3)
                .attr('stroke', function (d, index) {
                    return getColor(i);
                });
        }
        // �������ֱ�ǩ����
        var textPoints = [];
        var textRadius = radius + 20;
        for (var i = 0; i < total; i++) {
            var x = textRadius * Math.sin(i * onePiece),
                y = textRadius * Math.cos(i * onePiece);
            textPoints.push({
                x: x,
                y: y
            });
        }
        // �������ֱ�ǩ
        var texts = main.append('g')
            .classed('texts', true);
        texts.selectAll('text')
            .data(textPoints)
            .enter()
            .append('text')
            .attr('x', function (d) {
                return d.x;
            })
            .attr('y', function (d) {
                return d.y;
            })
            .text(function (d, i) {
                return data.fieldNames[i];
            });
    })




};


function getColor(idx) {

    var palette = [
        '#2ec7c9', '#b6a2de', '#5ab1ef', '#ffb980', '#d87a80',
        '#8d98b3', '#e5cf0d', '#97b552', '#95706d', '#dc69aa',
        '#07a2a4', '#9a7fd1', '#588dd5', '#f5994e', '#c05050',
        '#59678c', '#c9ab00', '#7eb00a', '#6f5553', '#c14089'
    ]
    return palette[idx % palette.length];
}



